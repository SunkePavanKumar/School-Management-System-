package SchoolManagementSystem;
/***
 * 
 * @author s.pavan kumar
 * This Class is responsible for keeping track od the 
 * Student name ,student id ,Grade and the Fee Paid
 * 
 *
 */
public class Student {
	private int id;
	private String name;
	private int grade;
	private int feepaid;
	private int feetotal;
	
	/**
	 * Creating the Constructor for the Parameters
	 * @param id
	 * @param name
	 * @param grade
	 * Lets us Assume that the fee is 30000
	 * Initial fee when the Object is created is 
	 * zero
	 * 
	 */
public Student(int id,String name,int grade) {
		this.feepaid=0;
		this.feetotal=30000;
		this.id=id;
		this.name=name;
		this.grade=grade;
}
/*
 * Setting the Grade  for the Student used to 
 * update  the student grade the parameter grade will be new Grade
 * 
 */
public void setgGrade(int grade) {
	this.grade=grade;
}
/**
 * Update the fees whenever the Student 
 * pays the fees
 * 
 * @param fees :Is the  fees that the Student Pays
 */
public void UpdateFeesPaid(int fees) {
	this.feepaid+=fees;
	School.updateTotalMoneyEarned(feepaid);

}
/*
 * return the Id of the Student
 */
public int getId() {
	return id;
}
/**
 * 
 * @return the name of the Student
 */
public String getName() {
	return name;
}
/**
 * 
 * @return the Grade of the Student
 */
public int getGrade() {
	return grade;
}
/*
 * @return the Feespaid by the Student
 */
public int getFeepaid() {
	return feepaid;
}
/**
 *  return the total fees of the student
 */
public int getFeetotal() {
	return feetotal;
}
/**
 * 
 * @return the remaining fee he should  pay
 * 
 */
public int getRemainingFee() {
	return feetotal-=feepaid;
}
@Override
public String toString() {
	return "Student name: "+name+ "Total Fees paid so far $"+feepaid;
}

	}
