package SchoolManagementSystem;
import java.util.*;
public class School {
	/**
	 * the School can have Many Teachers 
	 * the can have many Student;
	 * Implements the Teachers and the student using the ArrayList
	 * 
	 */
	private List<Teachers> teacher;
	private List<Student> student;
	private static int totalMoneyEarned;
	private static int totalMoneySpent;

	/**
	 * @param teacher: List of the teachers in the school
	 * @param student:List of the Students in the School
	 * @param totalMoneyEarned: 
	 * @param totalMoneySpent
	 */
	public School(List<Teachers> teacher, List<Student> student) {
		super();
		this.teacher = teacher;
		this.student = student;
		this.totalMoneyEarned =0;
		this.totalMoneySpent = 0;
	}
	/**
	 * 
	 * @return  the list  of the teacher in the  School
	 */
	public List<Teachers> getTeacher() {
		return teacher;
	}
	/**
	 * 
	 * @param teacher addds a teacher to a school
	 */

	public void addTeacher(Teachers teacher) {
		this.teacher.add(teacher);
	}
	/**
	 * 
	 * @return the  student of the school
	 */
	public List<Student> getStudent() {
		return student;
	}
	/**
	 * 
	 * @param student adds the students to the School
	 */

	public void updateStudent(Student student) {
		this.student.add(student);
	}
	/**
	 * 
	 * @return the total money Earned by the School
	 */

	public  int getTotalMoneyEarned() {
		return totalMoneyEarned;
	}
/**
 * 
 * @param MoneyEarned adds the total money Earned by the School which is the money given to
 * the teachers
 * 
 * 
 */
	public static  void updateTotalMoneyEarned(int MoneyEarned) {
		totalMoneyEarned +=MoneyEarned;
	}
	/**
	 * 
	 * @return the total money spent by the School
	 */

	public   int getTotalMoneySpent() {
		return totalMoneySpent;
	}
/**
 * 
 * @param totalMoneySpent update the money spent by the school
 * 
 */
	public static void updateTotalMoneySpent(int MoneySpent) {
		totalMoneyEarned-=MoneySpent;
		
	}
	
	

	
	
}
