package SchoolManagementSystem;

public class Teachers {
	/**
	 *Teacher class containing the id ,name,Salary
	 *
	 */
	private int id;
	private int salary;
	private  String name;
	private int salaryEarned;
	/**
	 * Creates a new teacher object  
	 * @param id unique id for the teacher
	 * 
	 * @param name of the  teacher 
	 * 
	 * @param salary of the teacher
	 */
public Teachers(int id,String name,int salary){
		this.id=id;
		this.name=name;
		this.salary=salary;
		this.salaryEarned=0;
		
	}
/**
 * 
 * @return the name of the teacher
 */
public String  getName() {
	return this.name;
}
 
/**
 * 
 * @return salary of the Teacher
 */
public int getSalary() {
	return this.salary;
}
/*
 * @return the id of the Teacher
 */
public int getId() {
	return this.id;
}
/*
 * Set the salary of the Teacher
 */
public void setSalary(int salary) {
	this.salary=salary;
	}
/**
 * adds to the salary
 * removes from the total money earned by the  school
 * @param salary 
 */
public void recieveSalary(int  salary) {
	salaryEarned+=salary;
    School.updateTotalMoneySpent(salary);;
	
}
@Override
public String toString() {
	return "Teacher name: "+name+ "Total Fees paid so far $"+salaryEarned;
}


}
