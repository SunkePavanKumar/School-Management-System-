package SchoolManagementSystem;
import java.util.*;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Teachers pavan=new Teachers(1,"pavan",70);
		Teachers Bhargav=new Teachers(2,"Bhargav",90);
		Teachers Jayanth=new Teachers(3,"Jayanth",100);
		
		
		Student bhargava =new Student(1,"bhargava",10);
		Student sai=new Student(2,"Sai",4);
		Student rohith=new Student(3,"Rohith",7);
		
		List<Teachers>teacher =new ArrayList<>();
		teacher.add(Jayanth);
		teacher.add(Bhargav);
		teacher.add(pavan);
		List<Student>student=new ArrayList<>();
		student.add(rohith);
		student.add(sai);
		student.add(bhargava);
		
		School GM=new School(teacher,student);
		
		bhargava.UpdateFeesPaid(5000);
		sai.UpdateFeesPaid(7000);
		System.out.println("GM Earned the total money of $"+ GM.getTotalMoneyEarned());
	    System.out.println("__________GM Pay Salary to the Teachers______________");
	    pavan.recieveSalary(pavan.getSalary());
	    System.out.println("The Total money the GM having after paying Salary "+pavan.getName()+" "+GM.getTotalMoneyEarned());
		Jayanth.recieveSalary(Jayanth.getSalary());
		 System.out.println("The Total money the GM having after paying Salary "+Jayanth .getName()+" "+GM.getTotalMoneyEarned());
		System.out.println(bhargava);
		System.out.println(Jayanth);
		System.out.println(pavan);
		System.out.println(Bhargav);
		
	}

}
